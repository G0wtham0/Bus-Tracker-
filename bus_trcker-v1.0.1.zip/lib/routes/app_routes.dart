import 'package:flutter/material.dart';
import 'package:bus_trcker/presentation/iphone_11_pro_max_five_screen/iphone_11_pro_max_five_screen.dart';
import 'package:bus_trcker/presentation/iphone_11_pro_max_four_screen/iphone_11_pro_max_four_screen.dart';
import 'package:bus_trcker/presentation/iphone_11_pro_max_six_screen/iphone_11_pro_max_six_screen.dart';
import 'package:bus_trcker/presentation/iphone_11_pro_max_one_screen/iphone_11_pro_max_one_screen.dart';
import 'package:bus_trcker/presentation/iphone_11_pro_max_three_screen/iphone_11_pro_max_three_screen.dart';
import 'package:bus_trcker/presentation/iphone_11_pro_max_two_screen/iphone_11_pro_max_two_screen.dart';
import 'package:bus_trcker/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String iphone11ProMaxFiveScreen =
      '/iphone_11_pro_max_five_screen';

  static const String iphone11ProMaxFourScreen =
      '/iphone_11_pro_max_four_screen';

  static const String iphone11ProMaxSixScreen = '/iphone_11_pro_max_six_screen';

  static const String iphone11ProMaxOneScreen = '/iphone_11_pro_max_one_screen';

  static const String iphone11ProMaxThreeScreen =
      '/iphone_11_pro_max_three_screen';

  static const String iphone11ProMaxTwoScreen = '/iphone_11_pro_max_two_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    iphone11ProMaxFiveScreen: (context) => Iphone11ProMaxFiveScreen(),
    iphone11ProMaxFourScreen: (context) => Iphone11ProMaxFourScreen(),
    iphone11ProMaxSixScreen: (context) => Iphone11ProMaxSixScreen(),
    iphone11ProMaxOneScreen: (context) => Iphone11ProMaxOneScreen(),
    iphone11ProMaxThreeScreen: (context) => Iphone11ProMaxThreeScreen(),
    iphone11ProMaxTwoScreen: (context) => Iphone11ProMaxTwoScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
