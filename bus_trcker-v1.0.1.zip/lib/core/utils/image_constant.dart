class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // iPhone 11 Pro Max - Five images
  static String imgImage2 = '$imagePath/img_image_2.png';

  // iPhone 11 Pro Max - One images
  static String imgIconLocation = '$imagePath/img_icon_location.svg';

  // iPhone 11 Pro Max - Three images
  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  // Common images
  static String imgVector = '$imagePath/img_vector.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
